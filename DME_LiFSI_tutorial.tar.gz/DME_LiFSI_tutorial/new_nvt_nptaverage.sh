#!/bin/bash

# Check if an ensemble argument was provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <ensemble>"
    exit 1
fi

# Define the ensemble variable from the first command line argument
ensemble="$1"

# Step 1: Extract the average box size from ${ensemble}.log
# Assuming the average box size is on the line immediately after "Box-X"
average_box_size=$(grep "Box-X" -A 1 "${ensemble}.log" | tail -n 1 | awk '{print $NF}')

echo "Average Box Size: $average_box_size"

# Step 2: Replace the box size in ${ensemble}.g96 with the average box size
# and save the output to ${ensemble}_averageV.g96
sed "/^BOX$/,/^END$/c\
BOX\n    $average_box_size    $average_box_size    $average_box_size\nEND" "${ensemble}.g96" > "${ensemble}_averageV.g96"

echo "Created ${ensemble}_averageV.g96 with the average box size."

