#!/bin/bash
#SBATCH --job-name=MSD
#SBATCH --time=4:00:00
#SBATCH --partition=compute
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16GB
#SBATCH --mail-type=ALL
#SBATCH --mail-user=r95222044@gmail.com
# below you run/call your code, load modules, python, Matlab, R, etc.
# and do any other scripting you want
# lines that begin with #SBATCH are directives (requests) to the scheduler-SLURM

source /home/mliao/gromacs2022.5.cpu/bin/GMXRC*


#gmx grompp -f ../mdpfiles/energy_min.mdp -c em.gro -p topol.top -o em2.tpr 
#gmx grompp -f eq.mdp         -c em2.gro -p topol.top -o eq.tpr 
#gmx grompp -f annealing.mdp -c em2.gro -p topol.top -o nvt.tpr 
#export exe_file=npt2

export OMP_NUM_THREADS=1

echo >> ~/slurm.log
export date=$(date) 
export currentdir=$(pwd) 
echo start $SLURM_JOB_ID $SLURM_JOB_NAME at $date  >> ~/slurm.log
echo $exe_file in $currentdir >> ~/slurm.log


#gmx trjconv -f nvt2.trr -s nvt2.tpr -pbc nojump -o nvt2-nojump.xtc  -n xtc_index.ndx 

#gmx trjconv -b 0 -e 1000 -f npt1.trr -s npt1.tpr -pbc nojump -o DEE1M1_0.6-FSI-nojump.pdb < 3.txt
#gmx trjconv -b 0 -e 1000 -f npt1.trr -s npt1.tpr -pbc nojump -o DEE1M1_0.6-Li-nojump.pdb < 4.txt

gmx trjconv -f npt3.trr -s npt3.tpr -pbc nojump -o npt3-nojump.xtc < 0.txt
gmx msd -beginfit 20000 -endfit 60000 -f npt3.trr -s npt3.tpr -o Li_msd.xvg < 4.txt
gmx msd -beginfit 20000 -endfit 60000 -f npt3.trr -s npt3.tpr -o FSI_msd.xvg < 3.txt

#gmx rdf -f nvt2.trr -s nvt2.tpr -n rdf_index.ndx -ref 3 -sel 4  -o nvt2_Li_N_rdf.xvg -cn nvt2_Li_N_rdfcn.xvg
#gmx rdf -f nvt2.trr -s nvt2.tpr -n rdf_index.ndx -ref 3 -sel 5  -o nvt2_Li_O_rdf.xvg -cn nvt2_Li_O_rdfcn.xvg

echo >> ~/slurm.log
export date=$(date) 
export currentdir=$(pwd) 
echo complete $SLURM_JOB_ID $SLURM_JOB_NAME at $date  >> ~/slurm.log
echo $exe_file in $currentdir >> ~/slurm.log
echo >> ~/slurm.log
